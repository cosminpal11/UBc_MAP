a=int(input('introduceti primul numar: '))
b=int(input('introduceti al 2-lea numar: '))
print('suma =', a+b)