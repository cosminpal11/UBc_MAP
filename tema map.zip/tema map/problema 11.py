n=int(input('introduceti un numar: '))
if(n>-1):
    print("pozitiv")
else:
    print('negativ')