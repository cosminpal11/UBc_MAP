nr=int(input('nr de elemente din lista: '))
s=0
v=[]
for i in range(0,nr):
    n=int(input())
    v.append(n)
    s=s+v[i]
print('suma = ',s)
print('media = ', s/nr)