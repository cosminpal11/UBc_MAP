p=1
i=0
while i<=10:
    p=p*i
    i+=1
print('produsul primelor 10 numere naturale:', p)