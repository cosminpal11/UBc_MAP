i=0
c=0
while c<=20:
    if i%2==1:
        print(i)
        c+=1
    i+=1
