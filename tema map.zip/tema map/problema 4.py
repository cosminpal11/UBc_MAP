a=input('introduceti primul numar:')
b=input('introduceti al 2-lea numar:')
while b:
    r=a%b
    a=b
    b=r
print (a)