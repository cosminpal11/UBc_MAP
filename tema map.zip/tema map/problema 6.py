n=int(input('introduce numar:'))
prim=2
for i in range(2,n,1):
    if n%i==0:
        prim=0
if prim==2:
    print('ESTE PRIM')
else:
    print('NU ESTE PRIM')