i=int(input('introduceti o cifra:'))
if i<8:
    if i==1:
        print('luni')
    if i==2:
        print('marti')
    if i==3:
        print('miercuri')
    if i==4:
        print('joi')
    if i==5:
        print('vineri')
    if i==6:
        print('sambata')
    if i==7:
        print('duminica')
