n=int(input('introduceti un numar: '))
if n%2==0:
    print('numar par')
else:
    print('numar impar')