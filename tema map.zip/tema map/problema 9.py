n=int(input('introduceti anul: '))
if (n%400==0) or (n%4==0 and n%100!=0):
    print('an bisect')
else:
    print ('an nebisect')